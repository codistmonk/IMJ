
function newViewer(id, filePrefix, tilePrefix, imageWidth, imageHeight, tileSize, lastLOD, tileFormat) {
	return OpenSeadragon({
	    id:            id,
	    prefixUrl:     filePrefix,
	    navigatorSizeRatio: 0.25,
	    wrapHorizontal:     false,
	    tileSources:   {
	        height: imageHeight,
	        width:  imageWidth,
	        tileSize: tileSize,
	        minLevel: 0,
		maxLevel: lastLOD,
	        getTileUrl: function( level, x, y ){
	            return tilePrefix + "lod" + (lastLOD - level) + "_y" + (y * tileSize) + "_x" + (x * tileSize) + "." + tileFormat;
	        }
	    }
	});
}

